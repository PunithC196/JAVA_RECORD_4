LAB-4-OOPS-JAVA

Contents
--------
LAB-4-OOPS-JAVA.docx
LAB-4-OOPS-JAVA_Images/   (trimmed and ordered evidence images)

Programs documented
-------------------
1. ParkingDemo.java
   - ParkingCharge interface
   - VehicleParking parent class
   - TwoWheeler and FourWheeler implementations
   - Verified charges: Rs. 60 for 4 hours (two-wheeler), Rs. 190 for 5 hours (four-wheeler)

2. Pay.java
   - Payment interface
   - CreditCardPayment, UPIPayment and PayPalPayment
   - Verified printed amounts: 100.0, 200.0 and 300.0

3. SalaryEmployee.java
   - Salary interface
   - PermanentEmployee and ContractEmployee
   - Verified salaries: Rs. 35,000 and Rs. 16,000

Screenshot capture date/time
----------------------------
Date shown in screenshots: 31-10-2026
ParkingDemo code: 08:09:49, 08:10:08, 08:10:21
ParkingDemo output: 08:10:40
Pay.java code: 08:39:40
SalaryEmployee.java code: 08:39:58
Pay and SalaryEmployee terminal output: 08:40:12

Notes
-----
- Images are cropped to focus on the relevant code/output while retaining the taskbar clock strip where available.
- The terminal capture includes an earlier failed compile attempt for Salary.java ("duplicate class: Salary"). The later SalaryEmployee.java compile and execution succeeded.
- The Pay program prints the amount but does not identify the payment method; this is a presentation improvement, not a calculation error.
